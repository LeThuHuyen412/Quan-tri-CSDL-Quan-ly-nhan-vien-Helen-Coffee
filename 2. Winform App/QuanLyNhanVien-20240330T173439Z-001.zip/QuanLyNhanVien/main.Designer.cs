﻿namespace QuanLyNhanVien
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.côngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lươngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bảngChấmCôngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bảngTổngHợpChấmCôngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bảngTổngHợpLươngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nhânViênToolStripMenuItem,
            this.côngToolStripMenuItem,
            this.lươngToolStripMenuItem,
            this.bảngChấmCôngToolStripMenuItem,
            this.bảngTổngHợpChấmCôngToolStripMenuItem,
            this.bảngTổngHợpLươngToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // nhânViênToolStripMenuItem
            // 
            this.nhânViênToolStripMenuItem.Name = "nhânViênToolStripMenuItem";
            this.nhânViênToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.nhânViênToolStripMenuItem.Text = "Nhân viên";
            this.nhânViênToolStripMenuItem.Click += new System.EventHandler(this.nhânViênToolStripMenuItem_Click);
            // 
            // côngToolStripMenuItem
            // 
            this.côngToolStripMenuItem.Name = "côngToolStripMenuItem";
            this.côngToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.côngToolStripMenuItem.Text = "Công";
            this.côngToolStripMenuItem.Click += new System.EventHandler(this.côngToolStripMenuItem_Click);
            // 
            // lươngToolStripMenuItem
            // 
            this.lươngToolStripMenuItem.Name = "lươngToolStripMenuItem";
            this.lươngToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.lươngToolStripMenuItem.Text = "Lương";
            this.lươngToolStripMenuItem.Click += new System.EventHandler(this.lươngToolStripMenuItem_Click);
            // 
            // bảngChấmCôngToolStripMenuItem
            // 
            this.bảngChấmCôngToolStripMenuItem.Name = "bảngChấmCôngToolStripMenuItem";
            this.bảngChấmCôngToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.bảngChấmCôngToolStripMenuItem.Text = "Bảng chấm công";
            this.bảngChấmCôngToolStripMenuItem.Click += new System.EventHandler(this.bảngChấmCôngToolStripMenuItem_Click);
            // 
            // bảngTổngHợpChấmCôngToolStripMenuItem
            // 
            this.bảngTổngHợpChấmCôngToolStripMenuItem.Name = "bảngTổngHợpChấmCôngToolStripMenuItem";
            this.bảngTổngHợpChấmCôngToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.bảngTổngHợpChấmCôngToolStripMenuItem.Text = "Bảng tổng hợp chấm công";
            this.bảngTổngHợpChấmCôngToolStripMenuItem.Click += new System.EventHandler(this.bảngTổngHợpChấmCôngToolStripMenuItem_Click);
            // 
            // bảngTổngHợpLươngToolStripMenuItem
            // 
            this.bảngTổngHợpLươngToolStripMenuItem.Name = "bảngTổngHợpLươngToolStripMenuItem";
            this.bảngTổngHợpLươngToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.bảngTổngHợpLươngToolStripMenuItem.Text = "Bảng tổng hợp lương";
            this.bảngTổngHợpLươngToolStripMenuItem.Click += new System.EventHandler(this.bảngTổngHợpLươngToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(313, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(402, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "QUẢN LÝ NHÂN VIÊN HELEN";
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = global::QuanLyNhanVien.Properties.Resources._393802015_905484140917507_6569462849450446120_n;
            this.pictureBox1.Image = global::QuanLyNhanVien.Properties.Resources._393802015_905484140917507_6569462849450446120_n;
            this.pictureBox1.InitialImage = global::QuanLyNhanVien.Properties.Resources._393802015_905484140917507_6569462849450446120_n;
            this.pictureBox1.Location = new System.Drawing.Point(300, 217);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(432, 211);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1008, 561);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem côngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lươngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bảngChấmCôngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bảngTổngHợpChấmCôngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bảngTổngHợpLươngToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}